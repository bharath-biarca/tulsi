
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.8.1'
version = '1.8.1'
full_version = '1.8.1'
git_revision = 'Unknown'
release = True

if not release:
    version = full_version
